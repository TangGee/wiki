package cn.com.erdo.activity;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffXfermode;
import android.graphics.Bitmap.Config;
import android.graphics.drawable.BitmapDrawable;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;

/*
 * 两种图片转换
 * 用工厂模式
 */
public class ScrawlActivity extends Activity {
	private int SCREEN_W;
	private int SCREEN_H;
	private int imagePosition;

	GameView gView;

	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
				WindowManager.LayoutParams.FLAG_FULLSCREEN);

		Intent intent = getIntent();
		String bgPath = null;
		String fgPath = null;
		try {
			bgPath = intent.getStringExtra("bgPath");
			fgPath = intent.getStringExtra("fgPath");
		} catch (Exception e) {
			e.printStackTrace();
		}
		if (bgPath != null && fgPath != null) {
			gView = new GameView(this, bgPath, fgPath);
		} else {
			imagePosition = intent.getIntExtra("imagePosition", 0);
			gView = new GameView(this);
		}

		setContentView(gView);
	}

	protected void onDestroy() {
		super.onDestroy();
		gView.recycleBitmap();
		Log.i("recycleBitmap", "recycleBitmap");
	}

	class GameView extends View {
		private Bitmap mFgBitmap;
		private Bitmap mBgBitmap;
		private Canvas mCanvas;
		private Paint mPaint;
		private Path mPath;
		private float mX, mY;
		private static final float TOUCH_TOLERANCE = 4;

		public GameView(Context context) {
			super(context);
			setFocusable(true);
			setScreenWH();
			setBackGround();
			int drawableId = 0;
			try {
				drawableId = R.drawable.class.getDeclaredField(
						"pre" + imagePosition).getInt(this);
			} catch (Exception e) {
				e.printStackTrace();
			}
			mBgBitmap = scaleBitmapFillScreen(BitmapFactory.decodeResource(
					getResources(), drawableId));
			setFrontgroundBitmap(mBgBitmap);
		}

		public GameView(Context context, String bgPath, String fgPath) {
			super(context);
			setFocusable(true);
			setScreenWH();
			setBackGround(context, bgPath);
			mBgBitmap = scaleBitmapFillScreen(readBitmap(fgPath));
			setFrontgroundBitmap(mBgBitmap);
		}

		private void setScreenWH() {
			DisplayMetrics dm = new DisplayMetrics();
			dm = this.getResources().getDisplayMetrics();
			int screenWidth = dm.widthPixels;
			int screenHeight = dm.heightPixels;

			SCREEN_W = screenWidth;
			SCREEN_H = screenHeight;
		}

		/**
		 * 
		 * @param bm
		 * @note if bitmap is smaller than screen, you can scale it fill the
		 *       screen.
		 * @return
		 */
		private Bitmap scaleBitmapFillScreen(Bitmap bm) {
			return Bitmap.createScaledBitmap(bm, SCREEN_W, SCREEN_H, true);
		}

		/**
		 * 
		 */
		private void setBackGround() {
			int drawableId = 0;
			try {
				// 第二层 抹去的一层
				drawableId = R.drawable.class.getDeclaredField(
						"after" + imagePosition).getInt(this);
			} catch (Exception e) {
				e.printStackTrace();
			}
			setBackgroundResource(drawableId);
		}

		private void setBackGround(Context mContext, String path) {
			Bitmap bm = readBitmap(path);
			BitmapDrawable bd = new BitmapDrawable(mContext.getResources(), bm);
			setBackgroundDrawable(bd);
		}

		/**
		 * 
		 * @param bm
		 * @note set icon1 bitmap , which overlay on background.
		 */
		private void setFrontgroundBitmap(Bitmap bm) {
			// setting paint
			mPaint = new Paint();
			mPaint.setAlpha(0);
			mPaint.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.DST_IN));
			// 消除锯齿
			mPaint.setAntiAlias(true);

			mPaint.setDither(true);
			mPaint.setStyle(Paint.Style.STROKE);
			mPaint.setStrokeJoin(Paint.Join.ROUND); // 外边界距离
			mPaint.setStrokeCap(Paint.Cap.ROUND); // ��״
			mPaint.setStrokeWidth(40); // 画笔宽度
			// set path
			mPath = new Path();

			// converting bitmap into mutable bitmap
			mFgBitmap = Bitmap.createBitmap(SCREEN_W, SCREEN_H,
					Config.ARGB_8888);
			mCanvas = new Canvas();
			mCanvas.setBitmap(mFgBitmap);
			// drawXY will result on that Bitmap
			// be sure parameter is bm, not mFgBitmap
			mCanvas.drawBitmap(bm, 0, 0, null);
		}

		protected void onDraw(Canvas canvas) {
			canvas.drawBitmap(mFgBitmap, 0, 0, null);
			mCanvas.drawPath(mPath, mPaint);
			super.onDraw(canvas);
		}

		private void touch_start(float x, float y) {
			mPath.reset();
			// 起始坐标
			mPath.moveTo(x, y);
			mX = x;
			mY = y;
		}

		private void touch_move(float x, float y) {
			float dx = Math.abs(x - mX); // x轴距离绝对值
			float dy = Math.abs(y - mY); // 轴距离绝对值ֵ
			if (dx >= TOUCH_TOLERANCE || dy >= TOUCH_TOLERANCE) {
				// 绘制贝塞尔曲线
				mPath.quadTo(mX, mY, (x + mX) / 2, (y + mY) / 2);
				mX = x;
				mY = y;
			}
		}

		private void touch_up() {
			mPath.lineTo(mX, mY);
			// commit the path to our offscreen
			mCanvas.drawPath(mPath, mPaint);
			// kill this so we don't double draw
			mPath.reset();
		}

		public boolean onTouchEvent(MotionEvent event) {
			float x = event.getX();
			float y = event.getY();

			switch (event.getAction()) {
			case MotionEvent.ACTION_DOWN:
				touch_start(x, y);
				invalidate();
				break;
			case MotionEvent.ACTION_MOVE:
				touch_move(x, y);
				invalidate();
				break;
			case MotionEvent.ACTION_UP:
				touch_up();
				invalidate();
				break;
			}
			return true;
		}

		/**
		 * 回收
		 */
		public void recycleBitmap() {
			mFgBitmap.recycle();
			mBgBitmap.recycle();
		}

		/**
		 * 读取
		 */
		private Bitmap readBitmap(String path) {
			BitmapFactory.Options options = new BitmapFactory.Options();
			options.inPreferredConfig = Config.ARGB_8888;
			options.inSampleSize = 1;
			Bitmap bm = BitmapFactory.decodeFile(path, options);
			return bm;
		}

	}
}
