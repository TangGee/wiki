package cn.com.erdo.activity;

import java.io.InputStream;
import java.util.HashMap;


import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.Gallery;
import android.widget.ImageSwitcher;
import android.widget.ImageView;
import android.widget.AdapterView.OnItemSelectedListener;
import android.widget.Gallery.LayoutParams;
import android.widget.ViewSwitcher.ViewFactory;

public class MainActivity extends Activity implements ViewFactory {
	ImageSwitcher imageSwitcher;
	private Gallery mGallery;

	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.main);
		findView();
		setListener();
	}

	private void findView() {
		imageSwitcher = (ImageSwitcher) findViewById(R.id.image_switcher);
		imageSwitcher.setFactory(this);
		mGallery = (Gallery) findViewById(R.id.gallery);
		mGallery.setAdapter(new ImageAdapter(MainActivity.this));
	}

	private void setListener() {
		mGallery.setOnItemSelectedListener(new OnItemSelectedListener() {

			public void onItemSelected(AdapterView<?> parent, View view,
					int position, long id) {
				int drawableId = 0;
				try {
					//��һ��
					drawableId = R.drawable.class.getDeclaredField(
							"pre" + position).getInt(this);
					Log.i("pre", "pre" + position);

				} catch (Exception e) {
					e.printStackTrace();
				}
				releaseBitmap();
				imageSwitcher.setImageResource(drawableId);
			}

			public void onNothingSelected(AdapterView<?> parent) {
			}

		});

		imageSwitcher.setOnClickListener(new OnClickListener() {

			public void onClick(View v) {
				Intent intent = new Intent();
				intent.putExtra("imagePosition",
						mGallery.getSelectedItemPosition());
				intent.setClass(MainActivity.this, ScrawlActivity.class);

				startActivity(intent);
			}
		});
	}

	private void releaseBitmap() {
		// �洢��һ�������һ���ɼ�λ��֮���2��λ�õ�bitmap
		// ��dataCache��ʼ��ֻ�����ˣ�M=4+Gallery��ǰ�ɼ�view�ĸ�����M��bitmap
		ImageAdapter adapter = (ImageAdapter) mGallery.getAdapter();
		HashMap<Integer, Bitmap> dataCache = adapter.getDataCache();

		int start = mGallery.getFirstVisiblePosition() - 2;
		int end = mGallery.getLastVisiblePosition() + 2;

		Log.i("releaseBitmap", "start = " + start);

		// �ͷ�position<start֮���bitmap��Դ
		Bitmap delBitmap;
		for (int del = 0; del < start; del++) {
			delBitmap = dataCache.get(del);
			if (null != delBitmap) {
				dataCache.remove(del);
				delBitmap.recycle();
				Log.i("releaseBitmap", "del = " + del);
			}
		}

		freeBitmapFromIndex(end, dataCache);

	}

	private void freeBitmapFromIndex(int end, HashMap<Integer, Bitmap> dataCache) {
		Log.i("freeBitmapFromIndex", "end = " + end);

		Bitmap delBitmap;
		for (int del = end + 1; del < dataCache.size(); del++) {
			delBitmap = dataCache.get(del);
			if (null != delBitmap) {
				dataCache.remove(del);
				delBitmap.recycle();
				Log.i("freeBitmapFromIndex", "del = " + del);
			}
		}
	}

	public class ImageAdapter extends BaseAdapter {
		private Context mContext;
		private HashMap<Integer, Bitmap> dataCache = new HashMap<Integer, Bitmap>();

		public ImageAdapter(Context c) {
			mContext = c;
		}

		public int getCount() {
			return 11;
		}

		public Object getItem(int position) {
			return position;
		}

		public long getItemId(int position) {
			return position;
		}

		public View getView(int position, View convertView, ViewGroup parent) {
			ImageView iv = null;
			if (null == convertView) {
				iv = new ImageView(mContext);
				iv.setLayoutParams(new Gallery.LayoutParams(120, 120));
				convertView = iv;
			} else {
				iv = (ImageView) convertView;
			}

			Bitmap current = dataCache.get(position);
			if (null != current) {
				iv.setImageBitmap(current);
			} else {

				int drawableId = 0;
				try {
					drawableId = R.drawable.class.getDeclaredField(
					"pre" + position).getInt(this);
				} catch (Exception e) {
					e.printStackTrace();
				}
				current = readBitMap(mContext, drawableId);
				iv.setLayoutParams(new Gallery.LayoutParams(120, 120));
				iv.setImageBitmap(current);
				dataCache.put(position, current);
				Log.i("getView", "position = " + position);
			}

			return convertView;
		}

		public HashMap<Integer, Bitmap> getDataCache() {
			return dataCache;
		}
	}

	public View makeView() {
		// TODO Auto-generated method stub
		ImageView i = new ImageView(this);
		i.setBackgroundColor(0xFF000000);
		i.setScaleType(ImageView.ScaleType.FIT_CENTER);
		i.setLayoutParams(new ImageSwitcher.LayoutParams(
				LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT));
		return i;
	}

	/**
	 * 
	 * @param context
	 * @param resId
	 * @return bitmap
	 */
	public static Bitmap readBitMap(Context context, int resId) {
		BitmapFactory.Options opt = new BitmapFactory.Options();
		opt.inPreferredConfig = Bitmap.Config.RGB_565;
		opt.inPurgeable = true;
		opt.inInputShareable = true;

		InputStream is = context.getResources().openRawResource(resId);
		return BitmapFactory.decodeStream(is, null, opt);

	}
}
