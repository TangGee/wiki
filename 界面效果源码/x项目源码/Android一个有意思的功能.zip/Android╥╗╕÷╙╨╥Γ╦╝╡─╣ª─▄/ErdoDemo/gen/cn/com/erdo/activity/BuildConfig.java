/** Automatically generated file. DO NOT MODIFY */
package cn.com.erdo.activity;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}