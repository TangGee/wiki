package com.picture;

import com.ipypu.yp.BR;

public class YPushRecever  extends BR{

}

