package com.picture;

import com.ipypu.yp.PIA;


public class YiPushAct  extends PIA{

}
