/** Automatically generated file. DO NOT MODIFY */
package com.example.ddemo;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}