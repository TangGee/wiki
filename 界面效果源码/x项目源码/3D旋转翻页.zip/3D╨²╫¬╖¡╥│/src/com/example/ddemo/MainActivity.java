package com.example.ddemo;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.view.animation.Animation;
import android.view.animation.Animation.AnimationListener;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;

public class MainActivity extends Activity {

	private float mCenterX;
	private float mCenterY;
	private View mImageView1;
	private View mImageView2;
	private RelativeLayout container;
	private LinearLayout ll_gt;
	private LinearLayout ll_yw;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		getWindow().requestFeature(Window.FEATURE_NO_TITLE);
		setContentView(R.layout.activity_main);
		container = (RelativeLayout) findViewById(R.id.container);
		mCenterX = getWindowManager().getDefaultDisplay().getWidth() / 2;
		mCenterY = getWindowManager().getDefaultDisplay().getHeight() / 2;
		ll_gt = (LinearLayout) findViewById(R.id.ll_gt);
		ll_yw = (LinearLayout) findViewById(R.id.ll_yw);
	}

	public void click_gt(View view) {
		startAnimation();

	}

	public void click_yw(View view) {
		startAnimation();
	}
int x = 0;
	private void startAnimation() {
		
		Rotate3dAnimation outAnimation = new Rotate3dAnimation(0, 90,
				mCenterX, mCenterY);
		outAnimation.setDuration(500);
		outAnimation.setFillAfter(true);
		container.startAnimation(outAnimation);
		outAnimation.setAnimationListener(new AnimationListener() {
			
			@Override
			public void onAnimationStart(Animation animation) {
				
			}
			
			@Override
			public void onAnimationRepeat(Animation animation) {
				
			}
			
			@Override
			public void onAnimationEnd(Animation animation) {
				if (x == 0) {
					ll_yw.setVisibility(View.GONE);
					ll_gt.setVisibility(View.VISIBLE);
					x=1;
				} else {
					ll_gt.setVisibility(View.GONE);
					ll_yw.setVisibility(View.VISIBLE);
					x=0;
				}
				Rotate3dAnimation inAnimation = new Rotate3dAnimation(270, 360,
						mCenterX, mCenterY);
				inAnimation.setDuration(500);
				inAnimation.setFillAfter(true);
				container.startAnimation(inAnimation);
			}
		});
		
	}

}
