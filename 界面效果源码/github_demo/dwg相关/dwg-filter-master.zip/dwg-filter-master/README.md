dwg-filter
==========
AutoCAD dwg file document filter.

###Support version

 * R12
 * R13
 * R14
 * 2000 DWG
 * 2004 DWG
 
###License

GNU GPL v2.0




