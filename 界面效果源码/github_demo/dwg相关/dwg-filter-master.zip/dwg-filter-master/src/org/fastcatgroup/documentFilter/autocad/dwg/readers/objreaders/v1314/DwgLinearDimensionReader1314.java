/*
 * Created on 25-ene-2007 by azabala
 *
 */
package org.fastcatgroup.documentFilter.autocad.dwg.readers.objreaders.v1314;

import org.fastcatgroup.documentFilter.autocad.dwg.DwgObject;
import org.fastcatgroup.documentFilter.autocad.dwg.readers.IDwgFileReader;
import org.fastcatgroup.documentFilter.autocad.dwg.readers.IDwgObjectReader;

/**
 * @author alzabord
 *
 */
public class DwgLinearDimensionReader1314 implements IDwgObjectReader{

	/* (non-Javadoc)
	 * @see com.iver.cit.jdwglib.dwg.readers.IDwgObjectReader#readSpecificObj(int[], int, com.iver.cit.jdwglib.dwg.DwgObject)
	 */
	public void readSpecificObj(int[] data, int offset, DwgObject dwgObj) {
		// TODO Auto-generated method stub
		
	}

	/* (non-Javadoc)
	 * @see com.iver.cit.jdwglib.dwg.readers.IDwgObjectReader#setFileReader(com.iver.cit.jdwglib.dwg.readers.IDwgFileReader)
	 */
	public void setFileReader(IDwgFileReader headTailReader) {
		// TODO Auto-generated method stub
		
	}

}
